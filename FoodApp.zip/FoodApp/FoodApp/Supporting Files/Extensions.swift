//
//  Extensions.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 22.12.22.
//

import Foundation
import UIKit
import Lottie

extension UIViewController {
    
    func displayAlertMessage(messageToDisplay: String, title: String, actions: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: messageToDisplay, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (action: UIAlertAction!) in
            actions?()
        }
        
        alertController.addAction(okAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
}

extension UITapGestureRecognizer {
    func didTapAttributedTextInLabel(label: UILabel, inRange targetRange: NSRange) -> Bool {
        // Create instances of NSLayoutManager, NSTextContainer and NSTextStorage
        let layoutManager = NSLayoutManager()
        let textContainer = NSTextContainer(size: CGSize.zero)
        let textStorage = NSTextStorage(attributedString: label.attributedText!)
        
        // Configure layoutManager and textStorage
        layoutManager.addTextContainer(textContainer)
        textStorage.addLayoutManager(layoutManager)
        
        // Configure textContainer
        textContainer.lineFragmentPadding = 0.0
        textContainer.lineBreakMode = NSLineBreakMode.byWordWrapping
        textContainer.maximumNumberOfLines = label.numberOfLines
        let labelSize = label.bounds.size
        textContainer.size = labelSize
        
        // Find the tapped character location and compare it to the specified range
        let locationOfTouchInLabel = self.location(in: label)
        let textBoundingBox = layoutManager.usedRect(for: textContainer)
        let textContainerOffset = CGPoint(x: (labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x,
                                          y: (labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y);
        let locationOfTouchInTextContainer = CGPoint(x: locationOfTouchInLabel.x - textContainerOffset.x,
                                                     y: locationOfTouchInLabel.y - textContainerOffset.y);
        let indexOfCharacter = layoutManager.characterIndex(for: locationOfTouchInTextContainer, in: textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
//        indexOfCharacter = indexOfCharacter - 7
        
        return NSLocationInRange(indexOfCharacter, targetRange)
        
    }
}

extension UIViewController {
    func startAnimation(animationView: AnimationView, animationName: String = "load") {
        animationView.animation = Animation.named(animationName)
        animationView.contentMode = .scaleAspectFill
        animationView.animationSpeed = 0.5
        animationView.tintColor = UIColor.init(named: "mainColor")
        animationView.loopMode = .loop
        animationView.play()
        self.view.addSubview(animationView)
        animationView.layer.cornerRadius = 16
        animationView.heightAnchor.constraint(equalToConstant: 480).isActive = true
        animationView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        animationView.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        animationView.rightAnchor.constraint(equalTo: self.view.rightAnchor).isActive = true
        
        animationView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    func stopAnimation(animationView: AnimationView, animationName: String = "load") {
        animationView.stop()
        animationView.removeFromSuperview()
    }
}
