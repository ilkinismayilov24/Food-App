//
//  LoginVC.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 21.12.22.
//

import UIKit
import Firebase
import FirebaseAuth
import Lottie

class LoginVC: UIViewController {
    
    var animationView = AnimationView()
    
    @IBOutlet var loginLbl: UILabel! {
        didSet {
            loginLbl.text = "Login"
        }
    }
    @IBOutlet var loginDescLbl: UILabel! {
        didSet {
            loginDescLbl.text = "Login to your account - enjoy exclusive features and many more"
        }
    }
    
    
    @IBOutlet var mailLbl: UILabel! {
        didSet {
            mailLbl.text = " Mail"
        }
    }
    @IBOutlet var mailStackView: UIStackView!
    @IBOutlet var mailView: UIView! {
        didSet {
            mailView.layer.borderWidth = 2
            mailView.layer.borderColor = UIColor.lightGray.cgColor
            mailView.layer.cornerRadius = 12
        }
    }
    @IBOutlet var mailTF: UITextField! {
        didSet {
            mailTF.placeholder = "Mail"
            mailTF.textColor = UIColor.init(named: "textColor")
            mailTF.font = UIFont(name: "SourceSansPro-Regular", size: 16)
            mailTF.autocorrectionType = .no
            mailTF.autocapitalizationType = .none
            mailTF.textContentType = .emailAddress
            mailTF.delegate = self
        }
    }
    @IBOutlet var mailWrongLbl: UILabel! {
        didSet {
            mailWrongLbl.isHidden = true
            mailWrongLbl.textColor = .red
            mailWrongLbl.textAlignment = .center
            mailWrongLbl.text = "This field cannot be left empty"
            mailWrongLbl.font = UIFont(name: "SourceSansPro-Regular", size: 16)
        }
    }
    
    @IBOutlet var passwordLbl: UILabel!
    @IBOutlet var passwordStackView: UIStackView!
    @IBOutlet var passwordView: UIView! {
        didSet {
            passwordView.layer.borderWidth = 2
            passwordView.layer.borderColor = UIColor.lightGray.cgColor
            passwordView.layer.cornerRadius = 12
        }
    }
    @IBOutlet var passwordTF: UITextField! {
        didSet {
            passwordTF.placeholder = "Password"
            passwordTF.font = UIFont(name: "SourceSansPro-Regular", size: 16)
            passwordTF.autocorrectionType = .no
            passwordTF.autocapitalizationType = .none
            passwordTF.isSecureTextEntry = true
            passwordTF.textColor = UIColor.init(named: "textColor")
            passwordTF.delegate = self
        }
    }
    
    let rightButton = UIButton(type: .system)
    
    @IBOutlet var passwordWrongLbl: UILabel! {
        didSet {
            passwordWrongLbl.isHidden = true
            passwordWrongLbl.textColor = .red
            passwordWrongLbl.textAlignment = .center
            passwordWrongLbl.text = "This field cannot be left empty"
            passwordWrongLbl.font = UIFont(name: "SourceSansPro-Regular", size: 16)
        }
    }
    
    @IBOutlet var loginBtn: UIButton! {
        didSet {
            loginBtn.layer.cornerRadius = 10
            loginBtn.backgroundColor = UIColor.init(named: "mainColor")
            loginBtn.titleLabel?.textColor = .white
            loginBtn.titleLabel?.font = UIFont(name: "SourceSansPro-Regular", size: 20)
            loginBtn.setTitle("Login", for: .normal)
        }
    }
    
    @IBOutlet var signUpLbl: UILabel! {
        didSet {
            signUpLbl.font = UIFont(name: "SourceSansPro-SemiBold", size: 14)
            signUpLbl.textColor = .lightGray
            
            var firstAttributedString = NSMutableAttributedString()
            firstAttributedString = NSMutableAttributedString(string: "Not a member? Sign up")
            firstAttributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.init(named: "mainColor") as Any, range: NSRange(location: 14, length: 7))
            
            var secondAS = NSMutableAttributedString()
            secondAS = firstAttributedString
            secondAS.addAttribute(NSAttributedString.Key.font, value: UIFont(name: "SourceSansPro-Bold", size: 14)  as Any, range: NSRange(location: 14, length: 7))
            
            signUpLbl.isUserInteractionEnabled = true
            let signUpGesture = UITapGestureRecognizer(target: self, action: #selector(onSignUpTapped))
            signUpLbl.addGestureRecognizer(signUpGesture)
            
            signUpLbl.attributedText = secondAS
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.rightView()
    }
    
    
    @IBAction func loginBtnTapped(_ sender: Any) {
        self.startAnimation(animationView: animationView)
        guard let email = mailTF.text, mailTF.hasText,
              let password = passwordTF.text, passwordTF.hasText else {
            self.stopAnimation(animationView: animationView)
            self.displayAlertMessage(messageToDisplay: "", title: "Fields cannot be left empty")
            return
        }
        UserDefaults.standard.set(email, forKey: "name")
                
        FirebaseAuth.Auth.auth().signIn(withEmail: email, password: password) { [weak self] result, error in
            guard error == nil else {
                self?.stopAnimation(animationView: self!.animationView)
                self?.displayAlertMessage(messageToDisplay: error?.localizedDescription ?? "", title: "Unexpected error occured")
                return
            }
            Router.shared.presentTabBarVC { vc in
                self?.stopAnimation(animationView: self!.animationView)
                self?.present(vc, animated: true)
            }
        }
    }
    @objc func onSignUpTapped(_ gesture: UITapGestureRecognizer) {
        guard let text = self.signUpLbl.text else { return }
        let conditionsRange = (text as NSString).range(of: "Sign up")
        let cancellationRange = (text as NSString).range(of: "Not a member? ")
        
        if gesture.didTapAttributedTextInLabel(label: self.signUpLbl, inRange: conditionsRange) {
            Router.shared.presentSignUpVC { vc in
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true)
            }
        } else if gesture.didTapAttributedTextInLabel(label: self.signUpLbl, inRange: cancellationRange) {
            // empty
        }
    }
    
    func rightView() {
        rightButton.frame = CGRect(x: CGFloat(passwordTF.frame.size.width - 25), y: CGFloat(-5), width: CGFloat(25), height: CGFloat(25))
        rightButton.tintColor = UIColor.black
        rightButton.setImage(UIImage.init(named: "ic_hidden"), for: .normal)
        rightButton.addTarget(self, action: #selector(onHideShowTapped), for: .touchUpInside)
        passwordTF.rightView = rightButton
        passwordTF.rightViewMode = .always
    }
    @objc func onHideShowTapped() {
        self.rightButton.setImage(self.passwordTF.isSecureTextEntry == false ? UIImage.init(named: "ic_hidden"): UIImage.init(named: "ic_shown"), for: .normal)
        self.passwordTF.isSecureTextEntry.toggle()
    }
}

extension LoginVC: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.mailTF {
            self.mailView.layer.borderColor = UIColor.init(named: "mainColor")?.cgColor
        } else if textField == self.passwordTF {
            self.passwordView.layer.borderColor = UIColor.init(named: "mainColor")?.cgColor
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.mailTF {
            self.mailView.layer.borderColor = UIColor.lightGray.cgColor
        } else if textField == self.passwordTF {
            self.passwordView.layer.borderColor = UIColor.lightGray.cgColor
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
