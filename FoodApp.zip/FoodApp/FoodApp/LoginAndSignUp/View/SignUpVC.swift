//
//  SignUpVC.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 21.12.22.
//

import UIKit
import Firebase
import FirebaseAuth
import Lottie

class SignUpVC: UIViewController {
    
    let database = Firestore.firestore()
    
    var animationView = AnimationView()
    
    @IBOutlet var SignUpLbl: UILabel! {
        didSet {
            SignUpLbl.textColor = UIColor.init(named: "textColor")
            SignUpLbl.font = UIFont(name: "SourceSansPro-Bold", size: 32)
            SignUpLbl.text = "Sign Up"
        }
    }
    @IBOutlet var descLbl: UILabel! {
        didSet {
            descLbl.text = "Please fill in the form to continue"
        }
    }
    
    @IBOutlet var fullNameLbl: UILabel! {
        didSet {
            fullNameLbl.text = "Full Name"
        }
    }
    @IBOutlet var fullNameStack: UIStackView!
    @IBOutlet var fullNameView: UIView! {
        didSet {
            fullNameView.layer.borderWidth = 2
            fullNameView.layer.borderColor = UIColor.lightGray.cgColor
            fullNameView.layer.cornerRadius = 12
        }
    }
    @IBOutlet var fullNameTF: UITextField! {
        didSet {
            fullNameTF.placeholder = "Full Name"
            fullNameTF.textColor = UIColor.init(named: "textColor")
            fullNameTF.font = UIFont(name: "SourceSansPro-Regular", size: 16)
            fullNameTF.autocorrectionType = .no
            fullNameTF.autocapitalizationType = .none
            fullNameTF.delegate = self
        }
    }
    @IBOutlet var fullNameWrongLbl: UILabel! {
        didSet {
            fullNameWrongLbl.isHidden = true
            fullNameWrongLbl.textColor = .red
            fullNameWrongLbl.textAlignment = .center
            fullNameWrongLbl.text = "This field cannot be left empty"
            fullNameWrongLbl.font = UIFont(name: "SourceSansPro-Regular", size: 16)
        }
    }
    
    @IBOutlet var mailLbl: UILabel! {
        didSet {
            mailLbl.text = "Mail"
        }
    }
    @IBOutlet var mailStackView: UIStackView!
    @IBOutlet var mailView: UIView! {
        didSet {
            mailView.layer.borderWidth = 2
            mailView.layer.borderColor = UIColor.lightGray.cgColor
            mailView.layer.cornerRadius = 12
        }
    }
    @IBOutlet var mailTF: UITextField! {
        didSet {
            mailTF.placeholder = "Mail"
            mailTF.textColor = UIColor.init(named: "textColor")
            mailTF.font = UIFont(name: "SourceSansPro-Regular", size: 16)
            mailTF.autocorrectionType = .no
            mailTF.autocapitalizationType = .none
            mailTF.textContentType = .emailAddress
            mailTF.delegate = self
        }
    }
    @IBOutlet var mailWrongLbl: UILabel! {
        didSet {
            mailWrongLbl.isHidden = true
            mailWrongLbl.textColor = .red
            mailWrongLbl.textAlignment = .center
            mailWrongLbl.text = "This field cannot be left empty"
            mailWrongLbl.font = UIFont(name: "SourceSansPro-Regular", size: 16)
        }
    }
    
    @IBOutlet var passwordLbl: UILabel! {
        didSet {
            passwordLbl.text = "Password"
        }
    }
    @IBOutlet var passwordStackView: UIStackView!
    @IBOutlet var passwordView: UIView! {
        didSet {
            passwordView.layer.borderWidth = 2
            passwordView.layer.borderColor = UIColor.lightGray.cgColor
            passwordView.layer.cornerRadius = 12
        }
    }
    @IBOutlet var passwordTF: UITextField! {
        didSet {
            passwordTF.placeholder = "Password"
            passwordTF.textColor = UIColor.init(named: "textColor")
            passwordTF.font = UIFont(name: "SourceSansPro-Regular", size: 16)
            passwordTF.autocorrectionType = .no
            passwordTF.autocapitalizationType = .none
            passwordTF.isSecureTextEntry = true
            passwordTF.delegate = self
        }
    }
    
    let passwordRightButton = UIButton(type: .system)
    
    @IBOutlet var passwordWrongLbl: UILabel! {
        didSet {
            passwordWrongLbl.isHidden = true
            passwordWrongLbl.textColor = .red
            passwordWrongLbl.textAlignment = .center
            passwordWrongLbl.text = "This field cannot be left empty"
            passwordWrongLbl.font = UIFont(name: "SourceSansPro-Regular", size: 16)
        }
    }
    
    @IBOutlet var repeatePasswordLbl: UILabel! {
        didSet {
            repeatePasswordLbl.text = "Repeate password"
        }
    }
    @IBOutlet var repeatePasswordStackView: UIStackView!
    @IBOutlet var repeatePasswordView: UIView! {
        didSet {
            repeatePasswordView.layer.borderWidth = 2
            repeatePasswordView.layer.borderColor = UIColor.lightGray.cgColor
            repeatePasswordView.layer.cornerRadius = 12
        }
    }
    @IBOutlet var repeatePasswordTF: UITextField! {
        didSet {
            repeatePasswordTF.placeholder = "Repeate password"
            repeatePasswordTF.textColor = UIColor.init(named: "textColor")
            repeatePasswordTF.font = UIFont(name: "SourceSansPro-Regular", size: 16)
            repeatePasswordTF.autocorrectionType = .no
            repeatePasswordTF.autocapitalizationType = .none
            repeatePasswordTF.isSecureTextEntry = true
            repeatePasswordTF.delegate = self
        }
    }
    
    let repeateRightButton = UIButton(type: .system)
    
    @IBOutlet var repeatePasswordWrongLbl: UILabel!  {
        didSet {
            repeatePasswordWrongLbl.isHidden = true
            repeatePasswordWrongLbl.textColor = .red
            repeatePasswordWrongLbl.textAlignment = .center
            repeatePasswordWrongLbl.text = "This field cannot be left empty"
            repeatePasswordWrongLbl.font = UIFont(name: "SourceSansPro-Regular", size: 16)
        }
    }
    
    @IBOutlet var signUpBtn: UIButton! {
        didSet {
            signUpBtn.layer.cornerRadius = 10
            signUpBtn.backgroundColor = UIColor.init(named: "mainColor")
            signUpBtn.titleLabel?.textColor = .white
            signUpBtn.titleLabel?.font = UIFont(name: "SourceSansPro-Regular", size: 20)
            signUpBtn.setTitle("Sign Up", for: .normal)
        }
    }
    
    @IBOutlet var signInLbl: UILabel! {
        didSet {
            signInLbl.font = UIFont(name: "SourceSansPro-SemiBold", size: 14)
            signInLbl.textColor = .lightGray
            
            var firstAttributedString = NSMutableAttributedString()
            firstAttributedString = NSMutableAttributedString(string: "Already a member? Sign in")
            firstAttributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.init(named: "mainColor") as Any, range: NSRange(location: 18, length: 7))
            
            var secondAS = NSMutableAttributedString()
            secondAS = firstAttributedString
            secondAS.addAttribute(NSAttributedString.Key.font, value: UIFont(name: "SourceSansPro-Bold", size: 14)  as Any, range: NSRange(location: 18, length: 7))
            
            signInLbl.isUserInteractionEnabled = true
            let signUpGesture = UITapGestureRecognizer(target: self, action: #selector(onSignInTapped))
            signInLbl.addGestureRecognizer(signUpGesture)
            
            signInLbl.attributedText = secondAS
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.passwordRightView()
        self.repeateRightView()
    }
    @IBAction func signUpTapped(_ sender: Any) {
        self.startAnimation(animationView: animationView)
        guard let mail = mailTF.text, mailTF.hasText,
              let password = passwordTF.text, passwordTF.hasText,
              let repeatePassword = repeatePasswordTF.text, repeatePasswordTF.hasText,
              let name = fullNameTF.text, fullNameTF.hasText else {
            self.stopAnimation(animationView: animationView)
            self.displayAlertMessage(messageToDisplay: "Some fields are empty, please fill them before continuing", title: "Error!")
            return
        }
        
        if password != repeatePassword {
            self.stopAnimation(animationView: self.animationView)
            self.displayAlertMessage(messageToDisplay: "Passwords do not match", title: "Error!")
        } else {
            self.startAnimation(animationView: self.animationView)
            Firebase.Auth.auth().createUser(withEmail: mail, password: password) { [weak self] rsult, error in
                guard error == nil else {
                    self?.stopAnimation(animationView: self!.animationView)
                    self?.displayAlertMessage(messageToDisplay: error?.localizedDescription ?? "Unrecognized error occured", title: "Error!")
                    return
                }
                UserDefaults.standard.set(self?.fullNameTF.text!, forKey: "username")
                self?.stopAnimation(animationView: self!.animationView)
                Router.shared.presentTabBarVC { vc in
                    self?.present(vc, animated: true)
                }
            }
        }
    }
    
    @objc func onSignInTapped(_ gesture: UITapGestureRecognizer) {
        guard let text = self.signInLbl.text else { return }
        let conditionsRange = (text as NSString).range(of: "Sign in")
        let cancellationRange = (text as NSString).range(of: "Already a member? ")
        
        if gesture.didTapAttributedTextInLabel(label: self.signInLbl, inRange: conditionsRange) {
            self.dismiss(animated: true)
        } else if gesture.didTapAttributedTextInLabel(label: self.signInLbl, inRange: cancellationRange) {
            // empty
        }
    }
}

extension SignUpVC: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.fullNameTF {
            self.fullNameView.layer.borderColor = UIColor.init(named: "mainColor")?.cgColor
        }  else if textField == self.mailTF {
            self.mailView.layer.borderColor = UIColor.init(named: "mainColor")?.cgColor
        } else if textField == self.passwordTF {
            self.passwordView.layer.borderColor = UIColor.init(named: "mainColor")?.cgColor
        } else if textField == self.repeatePasswordTF {
            self.repeatePasswordView.layer.borderColor = UIColor.init(named: "mainColor")?.cgColor
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.fullNameTF {
            self.fullNameView.layer.borderColor = UIColor.lightGray.cgColor
        } else if textField == self.mailTF {
            self.mailView.layer.borderColor = UIColor.lightGray.cgColor
        } else if textField == self.passwordTF {
            self.passwordView.layer.borderColor = UIColor.lightGray.cgColor
        } else if textField == self.repeatePasswordTF {
            self.repeatePasswordView.layer.borderColor = UIColor.lightGray.cgColor
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
}

extension SignUpVC {
    func passwordRightView() {
        passwordRightButton.frame = CGRect(x: CGFloat(passwordTF.frame.size.width - 25), y: CGFloat(-5), width: CGFloat(25), height: CGFloat(25))
        passwordRightButton.tintColor = UIColor.black
        passwordRightButton.setImage(UIImage.init(named: "ic_hidden"), for: .normal)
        passwordRightButton.addTarget(self, action: #selector(onHidePasswordTapped), for: .touchUpInside)
        passwordTF.rightView = passwordRightButton
        passwordTF.rightViewMode = .always
    }
    @objc func onHidePasswordTapped() {
        self.passwordRightButton.setImage(self.passwordTF.isSecureTextEntry == false ? UIImage.init(named: "ic_hidden"): UIImage.init(named: "ic_shown"), for: .normal)
        self.passwordTF.isSecureTextEntry.toggle()
    }
    
    func repeateRightView() {
        repeateRightButton.frame = CGRect(x: CGFloat(repeatePasswordTF.frame.size.width - 25), y: CGFloat(-5), width: CGFloat(25), height: CGFloat(25))
        repeateRightButton.tintColor = UIColor.black
        repeateRightButton.setImage(UIImage.init(named: "ic_hidden"), for: .normal)
        repeateRightButton.addTarget(self, action: #selector(onHideRepeateTapped), for: .touchUpInside)
        repeatePasswordTF.rightView = repeateRightButton
        repeatePasswordTF.rightViewMode = .always
    }
    @objc func onHideRepeateTapped() {
        self.repeateRightButton.setImage(self.repeatePasswordTF.isSecureTextEntry == false ? UIImage.init(named: "ic_hidden"): UIImage.init(named: "ic_shown"), for: .normal)
        self.repeatePasswordTF.isSecureTextEntry.toggle()
    }
}
