//
//  ProfileVC.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 24.12.22.
//

import UIKit
import FirebaseAuth

class ProfileVC: UIViewController {
    
    @IBOutlet var backView: UIView!
    @IBOutlet var textBack: UIView!
    
    @IBOutlet var firstLettersLbl: UILabel!
    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var logoutBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let name = UserDefaults.standard.value(forKey: "username")
        backView.layer.cornerRadius = 12
        textBack.layer.cornerRadius = 12
        logoutBtn.layer.cornerRadius = 12
        
        self.nameLbl.text = name as? String
        let split = self.nameLbl.text?.split(separator: " ")
        let firstLetter = split?.first?.capitalized
        let secondLetter = split?.last?.capitalized
        self.firstLettersLbl.text = "\((firstLetter?.first! ?? "a"))\(secondLetter?.first! ?? "a")"
        
    }
    
    @IBAction func logoutBtnTapped(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            Router.shared.presentLoginVC { vc in
                self.present(vc, animated: true)
            }
        }catch {
            print(error)
        }
    }
}
