//
//  SearchVC.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 17.12.22.
//

import Foundation
import UIKit

class SearchVC: UIViewController {
    
    var allFoods = [AllFoodsInfo]()
    var searchedFoods = [AllFoodsInfo]()
    
    @IBOutlet var backView: UIView! {
        didSet {
            backView.isUserInteractionEnabled = true
            let gesture = UITapGestureRecognizer(target: self, action: #selector(onBackTapped))
            backView.addGestureRecognizer(gesture)
        }
    }
    @IBOutlet var backImage: UIImageView! {
        didSet {
            backImage.image = UIImage.init(named: "ic_back")
        }
    }
    @IBOutlet var backLbl: UILabel! {
        didSet {
            backLbl.text = "Back"
        }
    }
    
    
    @IBOutlet var searchBar: UISearchBar! {
        didSet {
            searchBar.autocorrectionType = .no
            searchBar.autocapitalizationType = .none
            searchBar.placeholder = "Search for foods..."
            searchBar.delegate = self
            searchBar.searchBarStyle = .minimal
        }
    }
    @IBOutlet var tableView: UITableView! {
        didSet {
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.searchBar.becomeFirstResponder()
        navigationController?.navigationBar.isHidden = true
    }
    
    // MARK: - Functions
    @objc func onBackTapped() {
        self.dismiss(animated: true)
    }
}

extension SearchVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchedFoods = self.allFoods.filter { item in
            return item.name?.lowercased().contains(searchText.lowercased()) ?? false
        }
        print(self.searchedFoods)
        self.tableView.reloadData()
    }
}

extension SearchVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.searchedFoods.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: SearchCell.self), for: indexPath) as! SearchCell
        
        cell.setupCellWith(foodInfo: self.searchedFoods[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        Router.shared.presentDetailVC { vc in
            vc.id = self.searchedFoods[indexPath.row].id
            vc.foodDetail = self.searchedFoods[indexPath.row]
            vc.hidesBottomBarWhenPushed = true
            self.present(vc, animated: true)
        }
    }
}
