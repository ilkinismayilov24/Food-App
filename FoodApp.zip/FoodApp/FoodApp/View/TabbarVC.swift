//
//  TabbarVC.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 22.12.22.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore

public class TabbarVC: UITabBarController  {
    
    let database = Firestore.firestore()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        
        UITabBar.appearance().barTintColor = UIColor.init(named: "tabbarBackground")
        tabBar.barStyle = .default
        tabBar.tintColor = UIColor.init(named: "mainColor")
        tabBar.unselectedItemTintColor = .lightGray
        tabBar.isTranslucent = false
        tabBar.backgroundColor = UIColor.init(named: "tabbarBackground")
        
        let homeVC = storyBoard.instantiateViewController(withIdentifier: String(describing: HomeVC.self))
        let cartVC = storyBoard.instantiateViewController(withIdentifier: String(describing: CartVC.self))
        let profileVC = storyBoard.instantiateViewController(withIdentifier: String(describing: ProfileVC.self))
        
        let homeNav = UINavigationController(rootViewController: homeVC)
        let cartNav = UINavigationController(rootViewController: cartVC)
        let profileNav = UINavigationController(rootViewController: profileVC)
        
        homeNav.tabBarItem = UITabBarItem(title: "Home",
                                          image: UIImage.init(named: "ic_home"),
                                          selectedImage: UIImage.init(named: "ic_home_filled"))
        cartNav.tabBarItem = UITabBarItem(title: "Cart",
                                          image: UIImage.init(named: "ic_cart"),
                                          selectedImage: UIImage.init(named: "ic_cart_filled"))
        profileNav.tabBarItem = UITabBarItem(title: "Profile",
                                          image: UIImage.init(named: "ic_profile"),
                                          selectedImage: UIImage.init(named: "ic_profile_filled"))
        
        self.setViewControllers([homeNav, cartNav, profileNav], animated: false)
    }
}
