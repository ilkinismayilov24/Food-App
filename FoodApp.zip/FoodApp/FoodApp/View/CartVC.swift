//
//  CartVC.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 14.12.22.
//

import Foundation
import UIKit
import Lottie

class CartVC: UIViewController {
    let vm = CartVM()
    
    var animationView = AnimationView()
    
    @IBOutlet var tableView: UITableView! {
        didSet {
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.vm.getFoodForCart()
        self.vm.foodCartCompletion = {
            self.tableView.reloadData()
        }
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.topItem?.title = "Cart"
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.navigationBar.isHidden = false
    }
}

extension CartVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.vm.cartFoods.count == 0 {
            self.startAnimation(animationView: self.animationView, animationName: "emptyCart")
        } else {
            self.stopAnimation(animationView: self.animationView, animationName: "emptyCart")
        }
        return self.vm.cartFoods.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartCell", for: indexPath) as! CartCell
        
        cell.setupCellWith(foodInfo: self.vm.cartFoods[indexPath.row])
        
        cell.deleteCompletion = {
            self.vm.deleteFood(id: self.vm.cartFoods[indexPath.row].cartId ?? 0)
            self.vm.foodCartCompletion = {
                self.tableView.reloadData()
            }
//            self.vm.deleteCart = {
//                self.tableView.reloadData()
//            }
        }
        
        return cell
    }
}
