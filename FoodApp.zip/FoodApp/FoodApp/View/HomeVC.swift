//
//  ViewController.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 14.12.22.
//

import UIKit
import Kingfisher
import Lottie

class HomeVC: UIViewController {
    // MARK: - Variables
    var vm = HomeVM()
    
    // MARK: - UI Components
    var animationView = AnimationView()
    
    @IBOutlet var searchBar: UISearchBar! {
        didSet {
            searchBar.placeholder = "Search for foods..."
            searchBar.searchBarStyle = .minimal
            searchBar.delegate = self
        }
    }
    @IBOutlet var foodsTableView: UITableView! {
        didSet {
            foodsTableView.delegate = self
            foodsTableView.dataSource = self
        }
    }
    
    // MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        self.startAnimation()
        self.view.bringSubviewToFront(animationView)
        self.foodsTableView.isHidden = true
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.topItem?.title = "Foods"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            self.vm.getAllFoods()
            self.vm.allTicketsCompletion = { bool in
                guard bool == true else {
                    return
                }
                self.foodsTableView.isHidden = false
                self.view.sendSubviewToBack(self.animationView)
                self.foodsTableView.reloadData()
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
    }
    
    // MARK: - Functions
}

extension HomeVC: UISearchBarDelegate {
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        Router.shared.presentSearchVC { vc in
            vc.allFoods.append(contentsOf: self.vm.allMeals)
            vc.allFoods.append(contentsOf: self.vm.allDrinks)
            vc.allFoods.append(contentsOf: self.vm.allDesserts)
            self.present(vc, animated: true)
        }
    }
}

// MARK: - TableView
extension HomeVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MealsCell.self)) as! MealsCell
            
            cell.mealsArr = self.vm.allMeals
            cell.collectionView.reloadData()
            
            cell.completion = { id in
                Router.shared.presentDetailVC { vc in
                    vc.id = id
                    vc.foodDetail = self.vm.allMeals[id]
                    vc.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
            
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: DrinksCell.self)) as! DrinksCell
            print(self.vm.allDrinks)
            cell.drinksArr = self.vm.allDrinks
            cell.collectionView.reloadData()
            
            cell.completion = { id in
                Router.shared.presentDetailVC { vc in
                    vc.id = id
                    vc.foodDetail = self.vm.allDrinks[id]
                    vc.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
            
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: DessertsCell.self)) as! DessertsCell
            
            cell.dessertsArr = self.vm.allDesserts
            cell.collectionView.reloadData()
            
            cell.completion = { id in
                Router.shared.presentDetailVC { vc in
                    vc.id = id
                    vc.foodDetail = self.vm.allDesserts[id]
                    vc.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(vc, animated: true)

                }
            }
            
            return cell
        default:
            return UITableViewCell()
        }
    }
}

extension HomeVC {
    func startAnimation() {
           animationView.animation = Animation.named("load")
           animationView.contentMode = .scaleAspectFit
        animationView.animationSpeed = 0.5
        animationView.tintColor = UIColor.init(named: "mainColor")
           animationView.loopMode = .loop
           animationView.play()
           view.addSubview(animationView)
           animationView.layer.cornerRadius = 16
        animationView.heightAnchor.constraint(equalToConstant: 400).isActive = true
        animationView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        animationView.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        animationView.rightAnchor.constraint(equalTo: self.view.rightAnchor).isActive = true
        
        animationView.translatesAutoresizingMaskIntoConstraints = false
       }
}
