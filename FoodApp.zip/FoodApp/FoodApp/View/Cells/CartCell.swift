//
//  CartCell.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 23.12.22.
//

import UIKit

class CartCell: UITableViewCell {
    
    var deleteCompletion: (() -> Void)?
    
    private let baseForImage = "http://kasimadalan.pe.hu/foods/images/"
    
    @IBOutlet var backView: UIView! {
        didSet {
            backView.layer.cornerRadius = 12
            backView.layer.borderWidth = 1
            backView.layer.borderColor = UIColor.init(named: "mainColor")?.withAlphaComponent(0.3).cgColor
        }
    }
    @IBOutlet var imageBack: UIView! {
        didSet {
            imageBack.layer.cornerRadius = 12
            imageBack.backgroundColor = UIColor.init(named: "mainColor")?.withAlphaComponent(0.1)
        }
    }
    
    @IBOutlet var foodImage: UIImageView!
    
    @IBOutlet var nameLbl: UILabel!
    
    @IBOutlet var amountLbl: UILabel!
    
    @IBOutlet var priceLbl: UILabel!
    
    @IBOutlet var removeView: UIView! {
        didSet {
            let gesture = UITapGestureRecognizer(target: self, action: #selector(onDeleteTapped))
            removeView.isUserInteractionEnabled = true
            removeView.addGestureRecognizer(gesture)
        }
    }
    @IBOutlet var removeMinusView: UIView!
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @objc func onDeleteTapped() {
        self.deleteCompletion?()
    }
    
    func setupCellWith(foodInfo: FoodsCart?) {
        let imageUrl = URL(string: baseForImage + (foodInfo?.image ?? ""))
        self.foodImage.kf.setImage(with: imageUrl, placeholder: UIImage()) { result in
            switch result {
            case .success(let imageResult):
                self.foodImage.image = imageResult.image.withRenderingMode(.alwaysOriginal)
            case .failure(let err):
                print(err)
            }
        }
        
        self.nameLbl.text = foodInfo?.name
        let price = (foodInfo?.orderAmount ?? 1) * (foodInfo?.price ?? 1)
        self.priceLbl.text = "\(price) ₼"
        self.amountLbl.text = "\(foodInfo?.orderAmount ?? 0)"
    }
}
