//
//  DessertsCell.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 19.12.22.
//

import UIKit

class DessertsCell: UITableViewCell {
    
    var dessertsArr = [AllFoodsInfo]()
    var completion: ((Int) -> Void)?
    
    @IBOutlet var dessertsLbl: UILabel! {
        didSet {
            dessertsLbl.font = UIFont(name: "SourceSansPro-SemiBold", size: 24)
        }
    }
    
    @IBOutlet var collectionView: UICollectionView! {
        didSet {
            collectionView.delegate = self
            collectionView.dataSource = self
        }
    }
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

extension DessertsCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.dessertsArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: DessertsCollectionCell.self), for: indexPath) as! DessertsCollectionCell
        
        cell.setupCellWith(foodInfo: self.dessertsArr[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 200, height: 400)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.completion?(indexPath.row)
    }
}
