//
//  MealsCollectionCell.swift
//  FoodApp
//
//  Created by Ilkin Ismayilov on 20.12.22.
//

import Foundation
import UIKit

class MealsCollectionCell: UICollectionViewCell {
    
    private let baseForImage = "http://kasimadalan.pe.hu/foods/images/"
    
    @IBOutlet var backView: UIView! {
        didSet {
            backView.layer.cornerRadius = 12
            backView.layer.borderWidth = 2
            backView.layer.borderColor = UIColor.init(named: "mainColor")?.withAlphaComponent(0.5).cgColor
        }
    }
    @IBOutlet var foodImage: UIImageView!
    @IBOutlet var nameLbl: UILabel! {
        didSet {
            nameLbl.textColor = UIColor.init(named: "textColor")
            nameLbl.font = UIFont(name: "SourceSansPro-SemiBold", size: 20)
        }
    }
    @IBOutlet var priceLbl: UILabel! {
        didSet {
            priceLbl.textColor = UIColor.init(named: "textColor")
            priceLbl.font = UIFont(name: "SourceSansPro-SemiBold", size: 32)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setupCellWith(foodInfo: AllFoodsInfo?) {
        let imageUrl = URL(string: baseForImage + (foodInfo?.image ?? ""))
        self.foodImage.kf.setImage(with: imageUrl, placeholder: UIImage()) { result in
            switch result {
            case .success(let imageResult):
                self.foodImage.image = imageResult.image.withRenderingMode(.alwaysOriginal)
            case .failure(let err):
                print(err)
            }
        }
        self.nameLbl.text = foodInfo?.name
        self.priceLbl.text = "\(foodInfo?.price ?? 0) ₼"
    }
}

