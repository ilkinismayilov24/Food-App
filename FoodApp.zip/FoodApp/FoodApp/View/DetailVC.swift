//
//  DetailVC.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 14.12.22.
//

import Foundation
import UIKit
import Lottie

class DetailVC: UIViewController {
    // MARK: - Variables
    let vm = DetailVM()
    var id: Int?
    var foodDetail: AllFoodsInfo?
    var foodCount = 1
    var finalPrice = 0
    var alreadyCount = 0
    private let baseForImage = "http://kasimadalan.pe.hu/foods/images/"
    
    var testCompletion: (() -> Void)?
    
    // MARK: - UI Components
    var animationView = AnimationView()
    
    @IBOutlet var backBtn: UIButton! {
        didSet {
            backBtn.setTitle("", for: .normal)
            backBtn.setImage(UIImage.init(named: "ic_back_arrow"), for: .normal)
        }
    }
    @IBOutlet var cartImage: UIImageView! {
        didSet {
            cartImage.image = UIImage.init(named: "ic_cart")
            let gesture = UITapGestureRecognizer(target: self, action: #selector(onCartTapped))
            cartImage.isUserInteractionEnabled = true
            cartImage.addGestureRecognizer(gesture)
        }
    }
    @IBOutlet var cartTopView: UIView! {
        didSet {
            cartTopView.backgroundColor = UIColor.init(named: "mainColor")
            cartTopView.layer.cornerRadius = 6
        }
    }
    @IBOutlet var cartLbl: UILabel! {
        didSet {
            cartLbl.text = "\(self.vm.count)"
        }
    }
    
    @IBOutlet var imageView: UIImageView!
    
    @IBOutlet var decreaseView: UIView! {
        didSet {
            let gesture = UITapGestureRecognizer(target: self, action: #selector(onDecreaseTapped))
            decreaseView.isUserInteractionEnabled = true
            decreaseView.addGestureRecognizer(gesture)
            
            decreaseView.clipsToBounds = false
            decreaseView.layer.cornerRadius = 10
            decreaseView.layer.maskedCorners = [.layerMinXMaxYCorner]
        }
    }
    @IBOutlet var increaseView: UIView! {
        didSet {
            let gesture = UITapGestureRecognizer(target: self, action: #selector(onIncreaseTapped))
            increaseView.isUserInteractionEnabled = true
            increaseView.addGestureRecognizer(gesture)
            
            increaseView.clipsToBounds = false
            increaseView.layer.cornerRadius = 10
            increaseView.layer.maskedCorners = [.layerMaxXMaxYCorner]
        }
    }
    
    @IBOutlet var amountView: UIView!
    @IBOutlet var amountLbl: UILabel!
    
    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var priceLbl: UILabel!
    @IBOutlet var descLbl: UILabel!
    
    @IBOutlet var addToCartView: UIView! {
        didSet {
            addToCartView.layer.cornerRadius = 10
            addToCartView.isUserInteractionEnabled = true
            let gesture = UITapGestureRecognizer(target: self, action: #selector(onInsertTapped))
            addToCartView.addGestureRecognizer(gesture)
        }
    }
    @IBOutlet var addToCartLbl: UILabel! {
        didSet {
            addToCartLbl.text = "Add to Cart"
        }
    }
    @IBOutlet var addToCartAmountLbl: UILabel!
    
    // MARK: - Parent Delegate
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        self.loadData()
        
    }
    // MARK: - Functions
    
    @IBAction func backBtnTapped(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        self.dismiss(animated: true)
    }
    
    @objc func onDecreaseTapped() {
        self.foodCount = foodCount == 0 ? 0: foodCount - 1
        self.amountLbl.text = "\(self.foodCount)"
        self.finalPrice = self.foodCount * (self.foodDetail?.price ?? 1)
        self.addToCartAmountLbl.text = "\(finalPrice) ₼"
    }
    
    @objc func onIncreaseTapped() {
        self.foodCount += 1
        self.amountLbl.text = "\(self.foodCount)"
        self.finalPrice = self.foodCount * (self.foodDetail?.price ?? 1)
        self.addToCartAmountLbl.text = "\(finalPrice) ₼"
    }
    
    @objc func onInsertTapped() {
        self.startAnimation(animationView: animationView)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            for i in self.vm.cartFoods {
                if i.name == self.foodDetail?.name {
                    self.alreadyCount = i.orderAmount ?? 0
                    self.vm.deleteFood(id: i.cartId)
                    self.foodCount += self.alreadyCount
                }
            }
            self.vm.addToCart(foodInfo: self.foodDetail, amount: self.foodCount)
            self.foodCount -= self.alreadyCount
            self.vm.completion = { bool in
                guard bool == true else {
                    return
                }
                
                self.vm.getFoodFromCart()
                self.vm.countCompletion = { bool in
                    self.cartLbl.text = "\(self.vm.count)"
                    self.stopAnimation(animationView: self.animationView)
                }
                
            }
        }
    }
    
    @objc func onCartTapped() {
    }
    
    func loadData() {
        self.amountLbl.text = "1"
        let imageUrl = URL(string: baseForImage + (foodDetail?.image ?? ""))
        self.imageView.kf.setImage(with: imageUrl, placeholder: UIImage()) { result in
            switch result {
            case .success(let imageResult):
                self.imageView.image = imageResult.image.withRenderingMode(.alwaysOriginal)
            case .failure(let err):
                print(err)
            }
        }
        self.nameLbl.text = foodDetail?.name
        self.priceLbl.text = "\(foodDetail?.price ?? 0) ₼"
        self.addToCartAmountLbl.text = "\(foodDetail?.price ?? 0) ₼"
        
        self.vm.getFoodFromCart()
        self.vm.countCompletion = { bool in
            self.cartLbl.text = "\(self.vm.count)"
        }
    }
}
