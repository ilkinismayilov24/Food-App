//
//  GetsFoodFromCart.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 17.12.22.
//

import Foundation

struct Par: Codable {
    let userName: String?
}

struct FoodCart: Codable {
    let foods_cart: [FoodsCart]?
}

struct FoodsCart: Codable {
    let cartId: Int?
    let name, image: String?
    let price: Int?
    let category: String?
    let orderAmount: Int?
    let userName: String?
}
