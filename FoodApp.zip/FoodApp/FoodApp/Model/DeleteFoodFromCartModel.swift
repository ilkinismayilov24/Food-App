//
//  DeleteFoodFromCart.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 17.12.22.
//

import Foundation

struct DeleteParam: Codable {
    let cartId: Int
    let userName: String
}
