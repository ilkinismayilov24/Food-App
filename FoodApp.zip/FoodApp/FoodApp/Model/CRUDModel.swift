//
//  CRUDResponse.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 17.12.22.
//

import Foundation

struct CRUDResponse : Codable{
    let success:Int?
    let message:String?
}

