//
//  CartVM.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 14.12.22.
//

import UIKit

class CartVM {
    var foodCartCompletion: (() -> Void)?
    var deleteCart: (() -> Void)?
    var cartFoods = [FoodsCart]()
    
    func getFoodForCart() {
        self.cartFoods.removeAll()
        NetworkManager.shared.getFoodFromCart { result in
            switch result {
            case .success(let response):
                print(response)
                if let foods = response.foods_cart {
                    self.cartFoods = foods
                    self.foodCartCompletion?()
                }
            case .failure(let err):
                print(err)
            }
        }
        self.foodCartCompletion?()
    }
    
    func deleteFood(id: Int) {
        NetworkManager.shared.deleteFood(id: id) { result in
            
            switch result {
            case .success(let response):
                print(id)
                print(response)
                self.getFoodForCart()
            case .failure(let err):
                print(err)
            }
        }
    }
}
