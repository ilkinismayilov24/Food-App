//
//  DetailVM.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 14.12.22.
//

import Foundation

class DetailVM {
    
    var completion: ((Bool) -> Void)?
    var countCompletion: ((Bool) -> Void)?
    var count = 0
    var cartFoods = [FoodsCart]()
    
    func addToCart(foodInfo: AllFoodsInfo?, amount: Int) {
        
        NetworkManager.shared.insertFood(name: foodInfo?.name ?? "", image: foodInfo?.image ?? "", price: foodInfo?.price ?? 0, category: foodInfo?.category ?? "", orderAmount: amount) { result in
            switch result {
            case .success(let response):
                print(response)
                self.completion?(true)
            case .failure(let err):
                print(err)
                self.completion?(false)
            }
        }
    }
    
    func getFoodFromCart() {
        NetworkManager.shared.getFoodFromCart { result in
            switch result {
            case .success(let response):
                self.count = response.foods_cart?.count ?? 0
                if let foods = response.foods_cart {
                    self.cartFoods = foods
                }
                self.countCompletion?(true)
            case .failure(let err):
                print(err)
                self.countCompletion?(false)
            }
        }
    }
    
    func deleteFood(id: Int?) {
        print(id)
        NetworkManager.shared.deleteFood(id: id ?? 0) { result in
            switch result {
            case .success(let response):
                print(id)
                print(response)
            case .failure(let err):
                print(err)
            }
        }
    }
}
