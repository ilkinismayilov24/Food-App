//
//  HomeVM.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 14.12.22.
//

import Foundation

class HomeVM {
    
    var allTicketsCompletion: ((Bool) -> Void)?
    var allMeals = [AllFoodsInfo]()
    var allDrinks = [AllFoodsInfo]()
    var allDesserts = [AllFoodsInfo]()
    
    func getAllFoods() {
        NetworkManager.shared.getAllFoods { result in
            switch result {
            case .success(let response):
                self.allMeals.removeAll()
                self.allDrinks.removeAll()
                self.allDesserts.removeAll()
                if let foods = response.foods {
                    for i in foods {
                        if i.category == "Meals" {
                            self.allMeals.append(i)
                        } else if i.category == "Drinks" {
                            self.allDrinks.append(i)
                        } else if i.category == "Desserts" {
                            self.allDesserts.append(i)
                        }
                    }
                    self.allTicketsCompletion?(true)
                }
            case .failure(let err):
                print(err)
                self.allTicketsCompletion?(false)
            }
        }
    }
}
