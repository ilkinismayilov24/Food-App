//
//  NetworkManager.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 17.12.22.
//

import Foundation
import UIKit
import Alamofire

class NetworkManager{
    static let shared = NetworkManager()
    private init() {}
}

extension NetworkManager{
    
    func getAllFoods(completion: @escaping (Swift.Result<AllFoods,Error>)-> Void){
        let url = "http://kasimadalan.pe.hu/foods/getAllFoods.php"
        AF.request(url, method: .get).responseDecodable(of: AllFoods.self) { response in
            print(response)
            if let value = response.value {
                completion(.success(value))
            }
        }
    }
}
extension NetworkManager{
    func insertFood(name:String,image:String,price:Int,category:String,orderAmount:Int,completion: @escaping (Swift.Result<CRUDResponse,Error>)-> Void){
        var param = InsertParams(name: name, image: image, price: price, category: category, orderAmount: orderAmount, userName: UserDefaults.standard.value(forKey: "name") as! String)
        let url = "http://kasimadalan.pe.hu/foods/insertFood.php"
        
        do {
            let data = try JSONEncoder().encode(param)
            
            guard let params = try JSONSerialization.jsonObject(with: data, options: []) as? Parameters else {
                fatalError()
            }
            AF.request(URL(string: url)!,
                       method: .post,
                       parameters: params)
            .responseDecodable(of: CRUDResponse.self){ response in
                if let value = response.value {
                    completion(.success(value))
                }
            }
        } catch {
            print(error)
        }
    }
}

extension NetworkManager{
    func getFoodFromCart(completion: @escaping (Swift.Result<FoodCart,Error>)-> Void){
        let url = "http://kasimadalan.pe.hu/foods/getFoodsCart.php"
        let params = Par(userName: UserDefaults.standard.value(forKey: "name") as! String)
        do {
            let data = try JSONEncoder().encode(params)
            
            guard let params = try JSONSerialization.jsonObject(with: data, options: []) as? Parameters else {
                fatalError()
            }
            AF.request(URL(string: url)!,
                       method: .post,
                       parameters: params)
            .responseJSON { (response) in
                DispatchQueue.main.async {
                    switch response.result {
                    case .failure(let error):
                        print("\(#function) Error: \(error)")
                    case .success:
                        do {
                            let data1 = try JSONSerialization.jsonObject(with: response.data!)
                            print("1",data1)
                            let data = try JSONDecoder().decode(FoodCart.self, from: response.data!)
                            print(data)
                            completion(.success(data))
                        } catch(let decoderError) {
                            print("\(#function) Error decoding response:\nError: \(decoderError)")
                        }
                    }
                }
            }
        } catch {
            print(error)
        }
    }
}
extension NetworkManager {
    func deleteFood(id:Int,completion: @escaping (Swift.Result<CRUDResponse,Error>)-> Void) {
        let url = "http://kasimadalan.pe.hu/foods/deleteFood.php"
        let params = DeleteParam(cartId: id, userName: UserDefaults.standard.value(forKey: "name") as! String)
        do {
            let data = try JSONEncoder().encode(params)
            
            guard let params = try JSONSerialization.jsonObject(with: data, options: []) as? Parameters else {
                fatalError()
            }
            AF.request(URL(string: url)!,
                       method: .post,
                       parameters: params)
            .responseDecodable(of: CRUDResponse.self){ response in
                
                if let value = response.value {
                    completion(.success(value))
                }
            }
        } catch {
            print(error)
        }
    }
}
