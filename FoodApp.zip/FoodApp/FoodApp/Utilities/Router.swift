//
//  Router.swift
//  FoodApp
//
//  Created by İlkin İsmayilov on 17.12.22.
//

import Foundation
import UIKit

class Router{
    static let shared = Router()
    private init() {}
    
    func getViewController(id:String, storyboard:String = "Main") -> UIViewController{
        let storyBoard = UIStoryboard.init(name: storyboard, bundle: nil)
        let controller = storyBoard.instantiateViewController(withIdentifier: id)
        controller.modalTransitionStyle = .crossDissolve
        controller.modalPresentationStyle = .fullScreen
        return controller
    }
}

extension Router {
    func presentTabBarVC(complition: @escaping (TabbarVC) -> Void) {
        let controller = getViewController(id:String(describing: TabbarVC.self),
                                           storyboard: "Main") as! TabbarVC
        complition(controller)
    }
    
    func presentHomeVC(complition: @escaping (HomeVC) -> Void) {
        let controller = getViewController(id:String(describing: HomeVC.self),
                                           storyboard: "Main") as! HomeVC
        complition(controller)
    }
    
    func presentCartVC(complition: @escaping (CartVC) -> Void) {
        let controller = getViewController(id:String(describing: CartVC.self),
                                           storyboard: "Main") as! CartVC
        complition(controller)
    }
}

extension Router {
    func presentDetailVC(completion: @escaping (DetailVC) -> Void){
        let controller = getViewController(id: String(describing: DetailVC.self)) as! DetailVC
        completion(controller)
    }
}

extension Router {
    func presentSearchVC(completion: @escaping (SearchVC) -> Void){
        let controller = getViewController(id: String(describing: SearchVC.self)) as! SearchVC
        completion(controller)
        
    }
}

extension Router {
    func presentLoginVC(completion: @escaping (LoginVC) -> Void){
        let controller = getViewController(id: String(describing: LoginVC.self)) as! LoginVC
        completion(controller)
        
    }
    
    func presentSignUpVC(completion: @escaping (SignUpVC) -> Void){
        let controller = getViewController(id: String(describing: SignUpVC.self)) as! SignUpVC
        completion(controller)
        
    }
}
